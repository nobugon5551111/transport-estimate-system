PRAGMA defer_foreign_keys=TRUE;
CREATE TABLE d1_migrations(
		id         INTEGER PRIMARY KEY AUTOINCREMENT,
		name       TEXT UNIQUE,
		applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);
INSERT INTO "d1_migrations" VALUES(1,'0001_initial_schema.sql','2025-12-24 04:16:23');
INSERT INTO "d1_migrations" VALUES(2,'0002_add_multiple_vehicles.sql','2025-12-24 04:16:23');
INSERT INTO "d1_migrations" VALUES(3,'0003_add_report_and_ai_tables.sql','2025-12-24 04:16:24');
INSERT INTO "d1_migrations" VALUES(4,'0004_add_customer_status_management.sql','2025-12-24 04:16:24');
INSERT INTO "d1_migrations" VALUES(5,'0005_backup_system.sql','2025-12-24 04:16:25');
INSERT INTO "d1_migrations" VALUES(6,'0006_simple_auth.sql','2025-12-24 04:16:25');
INSERT INTO "d1_migrations" VALUES(7,'0007_backup_schedule.sql','2025-12-24 04:16:26');
INSERT INTO "d1_migrations" VALUES(8,'0008_add_project_priority_notes.sql','2025-12-24 04:16:26');
INSERT INTO "d1_migrations" VALUES(9,'0009_add_line_items_json.sql','2025-12-24 04:16:26');
INSERT INTO "d1_migrations" VALUES(10,'0010_add_free_estimate_items.sql','2025-12-24 04:16:27');
INSERT INTO "d1_migrations" VALUES(11,'0011_add_master_data_tables.sql','2025-12-24 04:16:27');
INSERT INTO "d1_migrations" VALUES(12,'0012_add_site_survey_fields.sql','2025-12-24 04:16:27');
INSERT INTO "d1_migrations" VALUES(13,'0013_add_customer_contact_person.sql','2025-12-24 04:16:28');
CREATE TABLE customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,                    
  contact_person TEXT,                   
  phone TEXT,                           
  email TEXT,                           
  address TEXT,                         
  notes TEXT,                           
  user_id TEXT NOT NULL,                
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
, status TEXT DEFAULT 'active', deleted_at DATETIME NULL, deleted_reason TEXT NULL);
INSERT INTO "customers" VALUES(3,'カッシーナ','','','','','','test-user-001','2025-12-24 06:07:57','2025-12-24 06:07:57','active',NULL,NULL);
CREATE TABLE projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL,          
  name TEXT NOT NULL,                    
  description TEXT,                      
  status TEXT NOT NULL DEFAULT 'initial', 
  user_id TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, priority TEXT DEFAULT 'medium', notes TEXT DEFAULT '',
  FOREIGN KEY (customer_id) REFERENCES customers(id)
);
INSERT INTO "projects" VALUES(3,3,'ホテル納品','','initial','test-user-001','2025-12-24 06:08:46','2025-12-24 06:08:46','medium','');
CREATE TABLE estimates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL,          
  project_id INTEGER NOT NULL,           
  estimate_number TEXT NOT NULL,         
  
  
  delivery_address TEXT NOT NULL,        
  delivery_postal_code TEXT,             
  delivery_area TEXT NOT NULL,           
  
  
  vehicle_type TEXT NOT NULL,            
  operation_type TEXT NOT NULL,          
  vehicle_cost REAL NOT NULL DEFAULT 0,  
  
  
  supervisor_count INTEGER DEFAULT 0,    
  leader_count INTEGER DEFAULT 0,        
  m2_staff_half_day INTEGER DEFAULT 0,   
  m2_staff_full_day INTEGER DEFAULT 0,   
  temp_staff_half_day INTEGER DEFAULT 0, 
  temp_staff_full_day INTEGER DEFAULT 0, 
  staff_cost REAL NOT NULL DEFAULT 0,    
  
  
  parking_officer_hours REAL DEFAULT 0,  
  parking_officer_cost REAL DEFAULT 0,   
  
  transport_vehicles INTEGER DEFAULT 0,   
  transport_within_20km BOOLEAN DEFAULT TRUE, 
  transport_distance REAL DEFAULT 0,     
  transport_fuel_cost REAL DEFAULT 0,    
  transport_cost REAL DEFAULT 0,         
  
  waste_disposal_size TEXT DEFAULT 'none', 
  waste_disposal_cost REAL DEFAULT 0,    
  
  protection_work BOOLEAN DEFAULT FALSE, 
  protection_floors INTEGER DEFAULT 0,   
  protection_cost REAL DEFAULT 0,        
  
  material_collection_size TEXT DEFAULT 'none', 
  material_collection_cost REAL DEFAULT 0, 
  
  construction_m2_staff INTEGER DEFAULT 0, 
  construction_partner TEXT,              
  construction_cost REAL DEFAULT 0,      
  
  work_time_type TEXT DEFAULT 'normal',  
  work_time_multiplier REAL DEFAULT 1.0, 
  
  parking_fee REAL DEFAULT 0,            
  highway_fee REAL DEFAULT 0,            
  
  
  subtotal REAL NOT NULL DEFAULT 0,      
  tax_rate REAL NOT NULL DEFAULT 0.1,    
  tax_amount REAL NOT NULL DEFAULT 0,    
  total_amount REAL NOT NULL DEFAULT 0,  
  
  
  notes TEXT,                            
  ai_email_generated TEXT,               
  pdf_generated BOOLEAN DEFAULT FALSE,   
  user_id TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, vehicle_2t_count INTEGER NOT NULL DEFAULT 0, vehicle_4t_count INTEGER NOT NULL DEFAULT 0, external_contractor_cost REAL NOT NULL DEFAULT 0, uses_multiple_vehicles BOOLEAN NOT NULL DEFAULT FALSE, created_by_name TEXT, line_items_json TEXT, site_survey_people INTEGER DEFAULT 0, site_survey_distance REAL DEFAULT 0, site_survey_base_cost REAL DEFAULT 0, site_survey_vehicle_cost REAL DEFAULT 0, site_survey_distance_cost REAL DEFAULT 0, site_survey_cost REAL DEFAULT 0, customer_contact_person TEXT DEFAULT '',
  
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (project_id) REFERENCES projects(id)
);
INSERT INTO "estimates" VALUES(1,3,3,'EST-2025-717','大阪府大阪市西区北堀江',NULL,'A','複数車両','終日',100000,0,1,0,2,0,1,51500,0,0,1,1,0,0,15000,'small',10000,0,1,11000,'few',5000,1,NULL,12500,'early',1.2,1000,2000,238300,0.1,23830,262130,'',NULL,0,'test-user-001','2025-12-24 06:17:44','2025-12-24 06:17:44',1,1,0,1,'管理者','{"vehicle":{"section_name":"車両費用","items":[{"description":"2t車 1台・終日（Aエリア）","detail":"@ ¥40,000","quantity":1,"unit_price":40000,"amount":40000},{"description":"4t車 1台・終日（Aエリア）","detail":"@ ¥60,000","quantity":1,"unit_price":60000,"amount":60000}],"subtotal":100000},"staff":{"section_name":"スタッフ費用","items":[{"description":"リーダー 1名","detail":"@ ¥15,000","quantity":1,"unit_price":15000,"amount":15000},{"description":"M2スタッフ（1日）2名","detail":"@ ¥12,500","quantity":2,"unit_price":12500,"amount":25000},{"description":"派遣スタッフ（1日）1名","detail":"@ ¥11,500","quantity":1,"unit_price":11500,"amount":11500}],"subtotal":51500},"services":{"section_name":"その他サービス費用","items":[{"description":"現地調査 2人（30km）","detail":"調査料金 ¥25,000 + 車両費 ¥5,000 + 追加距離 ¥188","quantity":1,"unit_price":30188,"amount":30188},{"description":"人員輸送車両 1台（20km圏内）","detail":"","quantity":1,"unit_price":15000,"amount":15000},{"description":"引き取り廃棄（small）","detail":"","quantity":1,"unit_price":10000,"amount":10000},{"description":"養生作業（基本料金）","detail":"","quantity":1,"unit_price":8000,"amount":8000},{"description":"養生作業（フロア単価）","detail":"1フロア × ¥3,000","quantity":1,"unit_price":3000,"amount":3000},{"description":"残材回収（few）","detail":"","quantity":1,"unit_price":5000,"amount":5000},{"description":"施工 M2スタッフ 1人","detail":"@ ¥12,500","quantity":1,"unit_price":12500,"amount":12500},{"description":"作業時間帯割増（early：+20%）","detail":"","quantity":1,"unit_price":30299.999999999993,"amount":30299.999999999993,"note":"※ 基準額: ¥151,500（車両+スタッフ）× 20%"},{"description":"実費：駐車料金","detail":"","quantity":1,"unit_price":1000,"amount":1000},{"description":"実費：高速料金","detail":"","quantity":1,"unit_price":2000,"amount":2000}],"subtotal":116988}}',2,30,25000,5000,188,30188,'齋藤');
INSERT INTO "estimates" VALUES(2,3,3,'EST-2025-677','東京都',NULL,'A','4t車','終日',50000,0,0,0,0,0,0,30000,0,0,0,1,0,0,0,'none',0,0,0,0,'none',0,0,NULL,0,'normal',1,0,0,80000,0.1,8000,88000,'',NULL,0,'admin','2025-12-24 06:48:45','2025-12-24 06:48:45',0,1,0,0,'未設定',NULL,0,0,0,0,0,0,'');
CREATE TABLE status_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,           
  estimate_id INTEGER,                   
  old_status TEXT,                       
  new_status TEXT NOT NULL,              
  notes TEXT,                           
  user_id TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id),
  FOREIGN KEY (estimate_id) REFERENCES estimates(id)
);
CREATE TABLE master_settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL,                
  subcategory TEXT NOT NULL,             
  key TEXT NOT NULL,                     
  value TEXT NOT NULL,                   
  data_type TEXT DEFAULT 'string',       
  description TEXT,                      
  user_id TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(category, subcategory, key, user_id)
);
CREATE TABLE area_settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  postal_code_prefix TEXT NOT NULL,      
  area_name TEXT NOT NULL,               
  area_rank TEXT NOT NULL,               
  user_id TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(postal_code_prefix, user_id)
);
CREATE TABLE ai_email_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  template_type TEXT NOT NULL,         
  customer_type TEXT NOT NULL,         
  project_type TEXT NOT NULL,          
  subject_template TEXT NOT NULL,      
  body_template TEXT NOT NULL,         
  success_rate REAL DEFAULT 0.5,       
  usage_count INTEGER DEFAULT 0,       
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "ai_email_templates" VALUES(1,'quote_initial','corporate','office_move','【見積書送付】{{customer_name}}様 オフィス移転お見積もり','{{customer_name}}様\n\nいつもお世話になっております。\nご依頼いただきましたオフィス移転のお見積もりをお送りいたします。\n\n見積金額: ¥{{total_amount}}\n\nご不明な点がございましたら、お気軽にお問い合わせください。',0.75,0,'2025-12-24 04:16:24','2025-12-24 04:16:24');
CREATE TABLE staff_optimization_patterns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_type TEXT NOT NULL,          
  operation_type TEXT NOT NULL,        
  delivery_area TEXT NOT NULL,         
  estimated_volume TEXT NOT NULL,      
  work_complexity TEXT NOT NULL,       
  recommended_supervisor INTEGER DEFAULT 0,
  recommended_leader INTEGER DEFAULT 0,
  recommended_m2_full INTEGER DEFAULT 0,
  recommended_m2_half INTEGER DEFAULT 0,
  recommended_temp_full INTEGER DEFAULT 0,
  recommended_temp_half INTEGER DEFAULT 0,
  success_rate REAL DEFAULT 0.5,       
  cost_efficiency REAL DEFAULT 0.5,    
  usage_count INTEGER DEFAULT 0,       
  notes TEXT,                          
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "staff_optimization_patterns" VALUES(1,'4t車','終日','Aエリア','medium','normal',1,2,3,0,0,0,0.85,0.8,0,NULL,'2025-12-24 04:16:24','2025-12-24 04:16:24');
CREATE TABLE report_cache (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  report_type TEXT NOT NULL,           
  period_start DATE,                   
  period_end DATE,                     
  parameters TEXT,                     
  data TEXT,                          
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME                  
);
INSERT INTO "report_cache" VALUES(1,'sales','2025-01-01','2025-01-31','{"period":"monthly"}','{"totalRevenue":201300,"totalOrders":2,"averageOrderValue":100650}','2025-12-24 04:16:24','2025-12-24 05:16:24');
CREATE TABLE ai_optimization_feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  estimate_id INTEGER NOT NULL,
  recommendation_id INTEGER,           
  recommended_config TEXT NOT NULL,    
  actual_config TEXT,                  
  actual_outcome TEXT,                 
  success_rating INTEGER CHECK(success_rating BETWEEN 1 AND 5), 
  cost_actual DECIMAL(10, 2),         
  cost_estimated DECIMAL(10, 2),      
  efficiency_score REAL,              
  notes TEXT,                         
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (estimate_id) REFERENCES estimates(id) ON DELETE CASCADE
);
CREATE TABLE ai_email_effectiveness (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email_template_id INTEGER NOT NULL,
  estimate_id INTEGER NOT NULL,
  customer_id INTEGER,
  email_type TEXT NOT NULL,            
  sent_at DATETIME,                    
  opened_at DATETIME,                  
  clicked_at DATETIME,                 
  responded_at DATETIME,               
  converted_at DATETIME,               
  open_rate REAL DEFAULT 0,            
  click_rate REAL DEFAULT 0,           
  response_rate REAL DEFAULT 0,        
  conversion_rate REAL DEFAULT 0,      
  customer_satisfaction INTEGER CHECK(customer_satisfaction BETWEEN 1 AND 5), 
  notes TEXT,                          
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (email_template_id) REFERENCES ai_email_templates(id) ON DELETE CASCADE,
  FOREIGN KEY (estimate_id) REFERENCES estimates(id) ON DELETE CASCADE,
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL
);
CREATE TABLE ai_prediction_accuracy (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  prediction_type TEXT NOT NULL,       
  prediction_period TEXT,              
  predicted_value REAL NOT NULL,       
  actual_value REAL,                   
  prediction_date DATE NOT NULL,       
  target_date DATE NOT NULL,           
  accuracy_score REAL,                 
  error_margin REAL,                   
  confidence_score REAL,               
  parameters TEXT,                     
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "ai_prediction_accuracy" VALUES(1,'sales','3months',250000,201300,'2025-01-01','2025-04-01',0.81,NULL,0.78,NULL,'2025-12-24 04:16:24','2025-12-24 04:16:24');
CREATE TABLE backup_metadata (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  backup_name TEXT NOT NULL,
  backup_type TEXT NOT NULL DEFAULT 'manual', 
  file_name TEXT NOT NULL,
  file_size INTEGER DEFAULT 0,
  record_count INTEGER DEFAULT 0,
  status TEXT DEFAULT 'pending', 
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME,
  created_by TEXT DEFAULT 'system',
  notes TEXT
);
INSERT INTO "backup_metadata" VALUES(1,'初期データバックアップ','manual','initial_backup_2024-08-22.json',15420,25,'completed','2024-08-22T10:00:00.000Z','2024-09-22T10:00:00.000Z','system',NULL);
INSERT INTO "backup_metadata" VALUES(2,'週次自動バックアップ','scheduled','weekly_backup_2024-08-22.json',28540,45,'completed','2024-08-22T02:00:00.000Z','2024-09-22T02:00:00.000Z','system',NULL);
INSERT INTO "backup_metadata" VALUES(3,'Manual Backup','manual','backup_2025-12-24T06-04-40-573Z.json',8066,30,'completed','2025-12-24T06:04:40.573Z','2026-01-23T06:04:40.615Z','system',NULL);
CREATE TABLE backup_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  backup_id INTEGER,
  operation_type TEXT NOT NULL, 
  operation_status TEXT NOT NULL, 
  operation_details TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  user_id TEXT,
  FOREIGN KEY (backup_id) REFERENCES backup_metadata(id)
);
CREATE TABLE users (
  id TEXT PRIMARY KEY,  
  name TEXT NOT NULL,   
  password TEXT NOT NULL,  
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "users" VALUES('admin','管理者','5307762ebbc42408cfd2e07263931521f92d5b39221691b0ce2d9a7973565e5f','2025-12-24 05:37:18');
CREATE TABLE sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
INSERT INTO "sessions" VALUES('12f433e8-a66b-45c4-9071-00032cc0d051','admin','2025-12-31T05:37:25.925Z','2025-12-24 05:37:25');
INSERT INTO "sessions" VALUES('b3d32b31-3634-4630-94f6-18a52993c55b','admin','2025-12-31T05:40:14.477Z','2025-12-24 05:40:14');
INSERT INTO "sessions" VALUES('882694ad-1477-45f2-9b34-1b1e8c7f03a3','admin','2025-12-31T05:40:30.818Z','2025-12-24 05:40:30');
INSERT INTO "sessions" VALUES('264df8ff-30a6-4660-90c1-29d03b04c58d','admin','2025-12-31T05:41:44.429Z','2025-12-24 05:41:44');
INSERT INTO "sessions" VALUES('54c6099c-1cf3-42f2-bd1a-a9717802250c','admin','2025-12-31T05:46:03.411Z','2025-12-24 05:46:03');
INSERT INTO "sessions" VALUES('69bcfdf2-f61d-43fa-a653-6fcd8fefc2e2','admin','2025-12-31T05:47:13.422Z','2025-12-24 05:47:13');
INSERT INTO "sessions" VALUES('567bc377-9b6a-426d-8c23-5900f61eb8ac','admin','2025-12-31T05:47:49.763Z','2025-12-24 05:47:49');
CREATE TABLE backup_schedules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  schedule_name TEXT NOT NULL,
  frequency TEXT NOT NULL, 
  frequency_value INTEGER, 
  time_hour INTEGER DEFAULT 2, 
  time_minute INTEGER DEFAULT 0, 
  target_tables TEXT, 
  retention_days INTEGER DEFAULT 30, 
  is_active INTEGER DEFAULT 1, 
  last_run DATETIME, 
  run_count INTEGER DEFAULT 0, 
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  created_by TEXT DEFAULT 'system'
);
INSERT INTO "backup_schedules" VALUES(1,'日次バックアップ','daily',NULL,2,0,'["customers", "projects", "estimates"]',7,1,NULL,0,'2025-12-24 04:16:26','2025-12-24 04:16:26','system');
INSERT INTO "backup_schedules" VALUES(2,'週次フルバックアップ','weekly',0,3,0,'["customers", "projects", "estimates", "vehicle_pricing", "staff_rates"]',30,1,NULL,0,'2025-12-24 04:16:26','2025-12-24 04:16:26','system');
INSERT INTO "backup_schedules" VALUES(3,'月次アーカイブ','monthly',1,1,0,'["customers", "projects", "estimates", "vehicle_pricing", "staff_rates"]',365,1,NULL,0,'2025-12-24 04:16:26','2025-12-24 04:16:26','system');
CREATE TABLE backup_execution_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  schedule_id INTEGER,
  backup_id INTEGER,
  execution_status TEXT NOT NULL, 
  execution_details TEXT,
  execution_time_ms INTEGER,
  executed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (schedule_id) REFERENCES backup_schedules(id),
  FOREIGN KEY (backup_id) REFERENCES backup_metadata(id)
);
CREATE TABLE free_estimate_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  estimate_id INTEGER NOT NULL,
  item_name TEXT NOT NULL,
  unit TEXT,
  quantity REAL DEFAULT 1,
  unit_price REAL DEFAULT 0,
  total_price REAL DEFAULT 0,
  sort_order INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (estimate_id) REFERENCES estimates(id) ON DELETE CASCADE
);
CREATE TABLE vehicle_pricing (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_type TEXT NOT NULL,        
  operation_type TEXT NOT NULL,      
  area TEXT NOT NULL,                
  price REAL NOT NULL,               
  user_id TEXT DEFAULT 'system',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(vehicle_type, operation_type, area, user_id)
);
INSERT INTO "vehicle_pricing" VALUES(1,'2t車','共配','A',25000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(2,'2t車','共配','B',28000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(3,'2t車','共配','C',30000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(4,'2t車','共配','D',32000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(5,'2t車','半日','A',30000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(6,'2t車','半日','B',33000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(7,'2t車','半日','C',35000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(8,'2t車','半日','D',37000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(9,'2t車','終日','A',40000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(10,'2t車','終日','B',43000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(11,'2t車','終日','C',45000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(12,'2t車','終日','D',47000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(13,'4t車','共配','A',35000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(14,'4t車','共配','B',38000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(15,'4t車','共配','C',40000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(16,'4t車','共配','D',42000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(17,'4t車','半日','A',45000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(18,'4t車','半日','B',48000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(19,'4t車','半日','C',50000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(20,'4t車','半日','D',52000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(21,'4t車','終日','A',60000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(22,'4t車','終日','B',63000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(23,'4t車','終日','C',65000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "vehicle_pricing" VALUES(24,'4t車','終日','D',67000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
CREATE TABLE staff_rates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  staff_type TEXT NOT NULL,          
  rate REAL NOT NULL,                
  user_id TEXT DEFAULT 'system',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(staff_type, user_id)
);
INSERT INTO "staff_rates" VALUES(1,'supervisor',18000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "staff_rates" VALUES(2,'leader',15000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "staff_rates" VALUES(3,'m2_full',12000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "staff_rates" VALUES(4,'m2_half',6000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "staff_rates" VALUES(5,'temp_full',10000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
INSERT INTO "staff_rates" VALUES(6,'temp_half',5000,'system','2025-12-24 04:16:27','2025-12-24 04:16:27');
DELETE FROM sqlite_sequence;
INSERT INTO "sqlite_sequence" VALUES('d1_migrations',13);
INSERT INTO "sqlite_sequence" VALUES('ai_email_templates',1);
INSERT INTO "sqlite_sequence" VALUES('staff_optimization_patterns',1);
INSERT INTO "sqlite_sequence" VALUES('report_cache',1);
INSERT INTO "sqlite_sequence" VALUES('ai_prediction_accuracy',1);
INSERT INTO "sqlite_sequence" VALUES('backup_metadata',3);
INSERT INTO "sqlite_sequence" VALUES('backup_schedules',3);
INSERT INTO "sqlite_sequence" VALUES('vehicle_pricing',24);
INSERT INTO "sqlite_sequence" VALUES('staff_rates',6);
INSERT INTO "sqlite_sequence" VALUES('customers',3);
INSERT INTO "sqlite_sequence" VALUES('projects',3);
INSERT INTO "sqlite_sequence" VALUES('estimates',2);
CREATE INDEX idx_customers_user_id ON customers(user_id);
CREATE INDEX idx_projects_customer_id ON projects(customer_id);
CREATE INDEX idx_projects_user_id ON projects(user_id);
CREATE INDEX idx_projects_status ON projects(status);
CREATE INDEX idx_estimates_customer_id ON estimates(customer_id);
CREATE INDEX idx_estimates_project_id ON estimates(project_id);
CREATE INDEX idx_estimates_user_id ON estimates(user_id);
CREATE INDEX idx_estimates_created_at ON estimates(created_at);
CREATE INDEX idx_status_history_project_id ON status_history(project_id);
CREATE INDEX idx_status_history_user_id ON status_history(user_id);
CREATE INDEX idx_master_settings_user_id ON master_settings(user_id);
CREATE INDEX idx_master_settings_category ON master_settings(category, subcategory);
CREATE INDEX idx_area_settings_user_id ON area_settings(user_id);
CREATE INDEX idx_area_settings_postal_code ON area_settings(postal_code_prefix);
CREATE INDEX idx_estimates_multiple_vehicles ON estimates(uses_multiple_vehicles);
CREATE INDEX idx_ai_email_templates_type ON ai_email_templates(template_type, customer_type, project_type);
CREATE INDEX idx_staff_patterns_vehicle ON staff_optimization_patterns(vehicle_type, operation_type);
CREATE INDEX idx_staff_patterns_area ON staff_optimization_patterns(delivery_area);
CREATE INDEX idx_report_cache_type ON report_cache(report_type);
CREATE INDEX idx_report_cache_period ON report_cache(period_start, period_end);
CREATE INDEX idx_report_cache_expires ON report_cache(expires_at);
CREATE INDEX idx_ai_feedback_estimate ON ai_optimization_feedback(estimate_id);
CREATE INDEX idx_ai_feedback_outcome ON ai_optimization_feedback(actual_outcome);
CREATE INDEX idx_ai_feedback_rating ON ai_optimization_feedback(success_rating);
CREATE INDEX idx_ai_email_template ON ai_email_effectiveness(email_template_id);
CREATE INDEX idx_ai_email_estimate ON ai_email_effectiveness(estimate_id);
CREATE INDEX idx_ai_email_customer ON ai_email_effectiveness(customer_id);
CREATE INDEX idx_ai_email_conversion ON ai_email_effectiveness(conversion_rate);
CREATE INDEX idx_ai_prediction_type ON ai_prediction_accuracy(prediction_type);
CREATE INDEX idx_ai_prediction_date ON ai_prediction_accuracy(prediction_date);
CREATE INDEX idx_ai_prediction_accuracy ON ai_prediction_accuracy(accuracy_score);
CREATE INDEX idx_customers_status ON customers(status);
CREATE INDEX idx_customers_deleted_at ON customers(deleted_at);
CREATE INDEX idx_backup_metadata_created_at ON backup_metadata(created_at);
CREATE INDEX idx_backup_metadata_status ON backup_metadata(status);
CREATE INDEX idx_backup_metadata_expires_at ON backup_metadata(expires_at);
CREATE INDEX idx_backup_history_backup_id ON backup_history(backup_id);
CREATE INDEX idx_backup_history_created_at ON backup_history(created_at);
CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_sessions_expires_at ON sessions(expires_at);
CREATE INDEX idx_backup_schedules_active ON backup_schedules(is_active);
CREATE INDEX idx_backup_schedules_frequency ON backup_schedules(frequency);
CREATE INDEX idx_backup_schedules_last_run ON backup_schedules(last_run);
CREATE INDEX idx_backup_execution_log_schedule_id ON backup_execution_log(schedule_id);
CREATE INDEX idx_backup_execution_log_executed_at ON backup_execution_log(executed_at);
CREATE INDEX idx_free_estimate_items_estimate_id ON free_estimate_items(estimate_id);
CREATE INDEX idx_free_estimate_items_sort_order ON free_estimate_items(estimate_id, sort_order);
CREATE INDEX idx_vehicle_pricing_lookup ON vehicle_pricing(vehicle_type, operation_type, area);
CREATE INDEX idx_staff_rates_type ON staff_rates(staff_type);
CREATE TRIGGER update_ai_feedback_timestamp 
AFTER UPDATE ON ai_optimization_feedback
BEGIN
  UPDATE ai_optimization_feedback SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
CREATE TRIGGER update_ai_email_timestamp 
AFTER UPDATE ON ai_email_effectiveness
BEGIN
  UPDATE ai_email_effectiveness SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
CREATE TRIGGER update_ai_prediction_timestamp 
AFTER UPDATE ON ai_prediction_accuracy
BEGIN
  UPDATE ai_prediction_accuracy SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
CREATE VIEW v_ai_effectiveness_summary AS
SELECT 
  'staff_optimization' as ai_feature,
  COUNT(*) as total_uses,
  AVG(success_rating) as avg_rating,
  AVG(efficiency_score) as avg_efficiency,
  SUM(CASE WHEN actual_outcome = 'success' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as success_rate
FROM ai_optimization_feedback
UNION ALL
SELECT 
  'email_generation' as ai_feature,
  COUNT(*) as total_uses,
  AVG(customer_satisfaction) as avg_rating,
  AVG(conversion_rate) as avg_efficiency,
  AVG(conversion_rate) * 100 as success_rate
FROM ai_email_effectiveness
WHERE conversion_rate IS NOT NULL;
CREATE VIEW v_report_usage_stats AS
SELECT 
  report_type,
  COUNT(*) as access_count,
  MAX(created_at) as last_accessed,
  AVG(julianday(expires_at) - julianday(created_at)) as avg_cache_duration_days
FROM report_cache
GROUP BY report_type;