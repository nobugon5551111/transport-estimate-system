# 輸送見積もりシステム - 完全バックアップ

## 📦 バックアップ情報

- **作成日時**: 2025年10月27日 03:09:43
- **タイムスタンプ**: 20251027_030934
- **Gitコミット**: fb4a743
- **Gitブランチ**: main
- **Node.js**: v20.19.3
- **npm**: 10.8.2

## 📋 含まれる内容

- ✅ ソースコード完全版（src/, public/）
- ✅ 設定ファイル（package.json, wrangler.jsonc, tsconfig.json, vite.config.ts）
- ✅ PM2設定（ecosystem.config.cjs）
- ✅ Git履歴（.git/）
- ✅ データベース完全バックアップ（database_backup.sql）
- ✅ ドキュメント（README.md, RESTORE_INSTRUCTIONS.md, DATABASE_SCHEMA.md）
- ✅ 自動復元スクリプト（RESTORE.sh）

## 🚀 復元方法（超簡単！）

### 方法1: 自動復元スクリプト（推奨）

```bash
# 1. ZIPファイルを展開
unzip webapp_complete_backup_20251027_030934.zip
cd webapp_complete_backup_20251027_030934

# 2. 復元スクリプトを実行（これだけ！）
./RESTORE.sh
```

**これだけで完全に復元されます！**

### 方法2: 手動復元

```bash
# 1. ZIPファイルを展開
unzip webapp_complete_backup_20251027_030934.zip
cd webapp_complete_backup_20251027_030934

# 2. ソースコードを配置
cp -r webapp /home/user/

# 3. 依存関係をインストール
cd /home/user/webapp
npm install

# 4. データベースを復元
rm -rf .wrangler/state/v3/d1
npx wrangler d1 migrations apply transport-estimate-production --local
npx wrangler d1 execute transport-estimate-production --local --file=../../webapp_complete_backup_20251027_030934/database_backup.sql

# 5. ビルドと起動
npm run build
fuser -k 3000/tcp 2>/dev/null || true
pm2 start ecosystem.config.cjs
```

## ✅ 完成済み機能

- **STEP1**: 顧客・案件選択
- **STEP2**: 配送先入力
- **STEP3**: 車両選択（詳細+合計表示）
- **STEP4**: スタッフ入力（詳細+合計表示）
- **STEP5**: その他サービス（詳細+合計表示）
- **STEP6**: 内容確認（完全転写方式）
- **PDF生成**: STEP6完全再現
- **マスター管理**: スタッフ・車両・サービス単価

## 📊 マスターデータ

### スタッフ単価
- スーパーバイザー: ¥40,000/日
- リーダー以上: ¥30,000/日
- M2スタッフ（終日）: ¥20,000/日
- 派遣スタッフ（終日）: ¥18,000/日

### サービス単価
- 駐車対策員: ¥2,500/時間
- 養生作業（基本）: ¥8,000
- 養生作業（フロア単価）: ¥3,000/フロア

### 車両単価（Aエリア・終日）
- 2t車: ¥40,000
- 4t車: ¥60,000

## 🔧 復元後の確認

```bash
# サービスが起動しているか確認
curl http://localhost:3000

# PM2ステータス確認
pm2 list

# ログ確認
pm2 logs --nostream
```

## 📝 重要な注意事項

1. **Node.js**: v18以上が必要
2. **PM2**: グローバルインストール必須（`npm install -g pm2`）
3. **Wrangler**: プロジェクト内にインストール済み
4. **ポート3000**: 他のプロセスで使用されていないこと

## 🆘 トラブルシューティング

### 復元スクリプトが実行できない
```bash
chmod +x RESTORE.sh
./RESTORE.sh
```

### ポート3000が使用中
```bash
fuser -k 3000/tcp
pm2 restart all
```

### データベースエラー
```bash
cd /home/user/webapp
rm -rf .wrangler/state/v3/d1
npx wrangler d1 migrations apply transport-estimate-production --local
npx wrangler d1 execute transport-estimate-production --local --file=PATH_TO_BACKUP/database_backup.sql
```

## 📞 サポート

復元に問題が発生した場合は、このREADMEと一緒に以下の情報を提供してください：
- エラーメッセージ
- 実行したコマンド
- `pm2 logs` の出力

---

**作成者**: 輸送見積もりシステム自動バックアップ  
**バックアップID**: webapp_complete_backup_20251027_030934
