#!/bin/bash

# =============================================================================
# 完全復元スクリプト
# =============================================================================
# このスクリプトを実行するだけで、システムが完全に復元されます
# =============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}==============================================================================${NC}"
echo -e "${BLUE}輸送見積もりシステム - 完全復元${NC}"
echo -e "${BLUE}==============================================================================${NC}"
echo ""

# 現在のディレクトリを確認
CURRENT_DIR=$(pwd)
echo -e "${YELLOW}📍 現在のディレクトリ: ${CURRENT_DIR}${NC}"
echo ""

# webapp ディレクトリが存在するか確認
if [ ! -d "${CURRENT_DIR}/webapp" ]; then
    echo -e "${RED}❌ エラー: webapp ディレクトリが見つかりません${NC}"
    echo -e "${YELLOW}このスクリプトは、展開したバックアップのルートディレクトリで実行してください${NC}"
    exit 1
fi

# 復元先ディレクトリ
TARGET_DIR="/home/user/webapp"

# 既存のディレクトリがある場合の処理
if [ -d "${TARGET_DIR}" ]; then
    echo -e "${YELLOW}⚠️  既存のディレクトリが見つかりました: ${TARGET_DIR}${NC}"
    echo -e "${YELLOW}   バックアップを作成してから上書きします${NC}"
    BACKUP_OLD="/home/user/webapp_old_$(date +%Y%m%d_%H%M%S)"
    mv "${TARGET_DIR}" "${BACKUP_OLD}"
    echo -e "   ✅ 既存ディレクトリを ${BACKUP_OLD} に移動しました"
fi

# 1. ソースコードを復元
echo -e "${GREEN}1. ソースコードを復元...${NC}"
mkdir -p /home/user
cp -r "${CURRENT_DIR}/webapp" "${TARGET_DIR}"
echo -e "   ✅ ソースコード復元完了"

# 2. 依存関係をインストール
echo -e "${GREEN}2. 依存関係をインストール...${NC}"
cd "${TARGET_DIR}"
npm install
echo -e "   ✅ npm install 完了"

# 3. データベースを復元
echo -e "${GREEN}3. データベースを復元...${NC}"

# 既存のデータベースを削除
if [ -d "${TARGET_DIR}/.wrangler/state/v3/d1" ]; then
    rm -rf "${TARGET_DIR}/.wrangler/state/v3/d1"
    echo -e "   ✅ 既存データベースを削除"
fi

# マイグレーション実行
npx wrangler d1 migrations apply transport-estimate-production --local 2>&1 | grep -v "npm notice" || true
echo -e "   ✅ マイグレーション実行完了"

# データベースバックアップをインポート
if [ -f "${CURRENT_DIR}/database_backup.sql" ]; then
    npx wrangler d1 execute transport-estimate-production --local --file="${CURRENT_DIR}/database_backup.sql" 2>&1 | grep -v "npm notice" || true
    echo -e "   ✅ データベースインポート完了"
else
    echo -e "${YELLOW}   ⚠️  database_backup.sql が見つかりません${NC}"
fi

# 4. ビルド
echo -e "${GREEN}4. プロジェクトをビルド...${NC}"
npm run build
echo -e "   ✅ ビルド完了"

# 5. PM2設定
echo -e "${GREEN}5. PM2でサービスを起動...${NC}"

# 既存のPM2プロセスを停止
pm2 delete all 2>/dev/null || true

# ポート3000をクリーンアップ
fuser -k 3000/tcp 2>/dev/null || true
sleep 2

# PM2で起動
pm2 start ecosystem.config.cjs
echo -e "   ✅ PM2起動完了"

sleep 3

# 6. 動作確認
echo -e "${GREEN}6. 動作確認...${NC}"
if curl -s http://localhost:3000 > /dev/null; then
    echo -e "   ✅ サービスが正常に起動しました"
else
    echo -e "${RED}   ❌ サービスの起動に失敗しました${NC}"
    echo -e "${YELLOW}   ログを確認してください: pm2 logs${NC}"
fi

echo ""
echo -e "${BLUE}==============================================================================${NC}"
echo -e "${GREEN}✅ 復元完了！${NC}"
echo -e "${BLUE}==============================================================================${NC}"
echo ""
echo -e "${YELLOW}📍 プロジェクトディレクトリ: ${TARGET_DIR}${NC}"
echo -e "${YELLOW}🌐 アクセスURL: http://localhost:3000${NC}"
echo -e "${YELLOW}📊 PM2ステータス: pm2 list${NC}"
echo -e "${YELLOW}📝 ログ確認: pm2 logs --nostream${NC}"
echo ""
echo -e "${GREEN}バックアップダウンロードページ: http://localhost:3000/backup-downloads${NC}"
echo ""

