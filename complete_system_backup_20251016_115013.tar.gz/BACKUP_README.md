# 輸送見積もりシステム - 完全バックアップ情報

**作成日時**: 2025年10月16日 11:50:13
**バックアップ時点のバージョン**: マスターデータ連動修正完了版

## 📋 バックアップ内容

### ✅ **修正済み機能**
- **Step4/5/6のAPI統一化**: 全ステップで `/master-settings` API使用
- **フィールド名統一**: `parking_officer_hourly` で統一
- **スタッフ単価**: 40,000円（スーパーバイザー）で統一
- **差額問題解決**: Step5とStep6の計算値が一致

### 🗃️ **バックアップファイル**

#### **1. プロジェクトコード全体**
- **ファイル**: `webapp_complete_backup_20251016_115013.tar.gz`
- **URL**: https://page.gensparksite.com/project_backups/webapp_complete_backup_20251016_115013.tar.gz
- **サイズ**: 4.1MB
- **内容**: 全ソースコード、設定ファイル、依存関係

#### **2. データベースバックアップ**
- **場所**: `database_backup/` ディレクトリ
- **スキーマ**: `schema.sql`
- **データ**: 各テーブルのJSONエクスポート
  - `master_settings_data.json`
  - `customers_data.json` 
  - `projects_data.json`
  - `estimates_data.json`
- **SQLiteファイル**: `sqlite_files/` ディレクトリ

#### **3. 設定ファイル**
- **場所**: `config_backup/` ディレクトリ
- **ファイル**: 
  - `wrangler.jsonc` - Cloudflare設定
  - `package.json` - 依存関係
  - `tsconfig.json` - TypeScript設定
  - `vite.config.ts` - Viteビルド設定
  - `ecosystem.config.cjs` - PM2設定
  - `.gitignore` - Git除外設定

## 🔄 **復元手順**

### **1. プロジェクトコードの復元**
```bash
# バックアップファイルをダウンロード
wget https://page.gensparksite.com/project_backups/webapp_complete_backup_20251016_115013.tar.gz

# 展開
tar -xzf webapp_complete_backup_20251016_115013.tar.gz

# 依存関係インストール
cd webapp && npm install

# ビルド
npm run build

# 開発サーバー起動
pm2 start ecosystem.config.cjs
```

### **2. データベースの復元**
```bash
# ローカルD1データベースのマイグレーション実行
npx wrangler d1 migrations apply transport-estimate-production --local

# データのインポート（必要に応じて）
# SQLファイルまたはJSONファイルからデータを復元
```

### **3. 環境確認**
- URL: http://localhost:3000
- Step4-6の動作確認
- マスターデータの一致確認

## 🛡️ **重要な修正内容**

### **API統一化**
- Step5: `/master-settings` API使用
- Step6: `/master-settings` API使用（`/service-rates` から変更）

### **フィールド名統一**  
- `parking_officer_hourly` で全ステップ統一
- `parking_officer_hourly_rate` は使用しない

### **単価の一致**
- スーパーバイザー: 40,000円/日
- 駐車対策員: 3,000円/時間
- 他全サービス項目: マスターデータと一致

## 📞 **トラブル時の対応**

1. **サービス起動失敗時**:
   ```bash
   fuser -k 3000/tcp
   pm2 delete all
   npm run build
   pm2 start ecosystem.config.cjs
   ```

2. **データベース問題時**:
   ```bash
   rm -rf .wrangler/state/v3/d1
   npx wrangler d1 migrations apply transport-estimate-production --local
   ```

3. **ビルドエラー時**:
   ```bash
   rm -rf node_modules dist
   npm install
   npm run build
   ```

---
**バックアップ作成者**: AI Assistant
**確認済み機能**: マスターデータ連動、Step4-6統一性、差額問題解決